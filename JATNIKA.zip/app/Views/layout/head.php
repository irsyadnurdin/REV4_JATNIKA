<title>ADMIN - SISTEM INFORMASI INVENTARIS</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="keywords" content="ADMIN - SISTEM INFORMASI INVENTARIS" />
<meta name="description" content="ADMIN - SISTEM INFORMASI INVENTARIS">
<meta name="author" content="JATNIKA">

<link href="<?= base_url('_img/favicon.png') ?>" rel="icon">
<link href="<?= base_url('_img/favicon.png') ?>" rel="apple-touch-icon">

<!-- SWEETALERT2 -->
<link href="<?= base_url('sweetalert/sweetalert2.css') ?>" rel="stylesheet">

<!-- MAGNIFIC POPUP-->
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.css">

<!-- ADMINISTRATOR -->
<link rel="stylesheet" href="<?= base_url('temp_admin/plugins/pace/pace.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/bower_components/bootstrap/dist/css/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/bower_components/font-awesome/css/font-awesome.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/bower_components/Ionicons/css/ionicons.min.css') ?>">

<!-- DATATABLE -->
<!-- <link rel="stylesheet" href="<?= base_url('temp_admin/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css') ?>"> -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
<!-- <link rel="stylesheet" href="<?php echo base_url('assets/datatable/jquery.dataTables.min.css') ?>"> -->
<link rel="stylesheet" href="https://cdn.datatables.net/rowreorder/1.2.7/css/rowReorder.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.5/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/select/1.3.1/css/select.dataTables.min.css">
<link rel="stylesheet" href="https://editor.datatables.net/extensions/Editor/css/editor.dataTables.min.css">

<!-- TABLEDIT -->           
<!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" /> -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" /> -->

<link rel="stylesheet" href="<?= base_url('temp_admin/dist/css/AdminLTE.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/dist/css/skins/_all-skins.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/bower_components/morris.js/morris.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/bower_components/jvectormap/jquery-jvectormap.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/bower_components/bootstrap-daterangepicker/daterangepicker.css') ?>">
<!-- <link rel="stylesheet" href="<?= base_url('temp_admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css') ?>"> -->
<link rel="stylesheet" href="<?= base_url('temp_admin/plugins/iCheck/all.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/bower_components/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/plugins/timepicker/bootstrap-timepicker.min.css') ?>">
<link rel="stylesheet" href="<?= base_url('temp_admin/bower_components/select2/dist/css/select2.min.css') ?>">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

<!-- STYLE -->
<link rel="stylesheet" href="<?php echo base_url('css/style-administrator.css') ?>">

<script charset="utf-8" src="//cdn.iframe.ly/embed.js?api_key=9be4d95c56b8b82d697205"></script>
