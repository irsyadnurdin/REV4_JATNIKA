<?php

namespace App\Controllers;

use App\Models\PenggunaModel;
use App\Models\RoleModel;
use App\Models\BarangModel;
use App\Models\PengecekanModel;
use App\Models\Pengecekan_DetailModel;
use App\Models\KriteriaModel;
use App\Models\PengadaanModel;
use App\Models\StatusModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\Controller;

class Pengadaan extends BaseController
{
    public function __construct() {
        $this->pengguna = new PenggunaModel();
        $this->role = new RoleModel();
        $this->barang = new BarangModel();
        $this->pengecekan = new PengecekanModel();
        $this->pengecekan_detail = new Pengecekan_DetailModel();
        $this->kriteria = new KriteriaModel();
        $this->pengadaan = new PengadaanModel();
        $this->status = new StatusModel();
    }
    

    // ===========================================================================
	// INDEX
	// ===========================================================================

	public function index()
    {
        $data['jd_barang'] = count($this->barang->findAll());
        $data['jd_pengecekan'] = count($this->pengecekan->findAll());
        $data['jd_pengadaan'] = count($this->pengadaan->findAll());
        
        $data["pengguna"] = $this->pengguna->find(session()->get('id_pengguna'));

        return view('pengadaan/index', $data);
    }


    // ===========================================================================
	// BARANG
	// ===========================================================================	

	public function barang($id = null)
	{
		$data["pengguna"] = $this->pengguna->find(session()->get('id_pengguna'));	
		
		if (!isset($id)) { 			
            $data['tgl_rekap_filter'] = "";
            $data['tgl_perolehan_filter'] = "";
            
		    $this->pengecekan->query("SET lc_time_names = 'id_ID';");
            $this->barang->select('
                *,
                DATE_FORMAT(tgl_rekap, "%W, %d %M %Y") AS _tgl_rekap, 
                DATE_FORMAT(tgl_perolehan, "%W, %d %M %Y") AS _tgl_perolehan, 
            ');		
            $this->barang->where('active', 1);

            $validation =  \Config\Services::validation();
            $validation->setRules([
                'tgl_rekap' => 'required',
            ]);
            $isDataValid = $validation->withRequest($this->request)->run();

            if ($isDataValid) {
                $tgl_rekap = $this->request->getPost('tgl_rekap');
                $exp = explode('-', $tgl_rekap);
                $data['tgl_rekap_filter'] = $tgl_rekap;

                $this->barang->where('DAY(tgl_rekap)', $exp[2]);
                $this->barang->where('MONTH(tgl_rekap)', $exp[1]);
                $this->barang->where('YEAR(tgl_rekap)', $exp[0]);
            }

            $validation =  \Config\Services::validation();
            $validation->setRules([
                'tgl_perolehan' => 'required',
            ]);
            $isDataValid = $validation->withRequest($this->request)->run();

            if ($isDataValid) {
                $tgl_perolehan = $this->request->getPost('tgl_perolehan');
                $exp = explode('-', $tgl_perolehan);
                $data['tgl_perolehan_filter'] = $tgl_perolehan;

                $this->barang->where('DAY(tgl_perolehan)', $exp[2]);
                $this->barang->where('MONTH(tgl_perolehan)', $exp[1]);
                $this->barang->where('YEAR(tgl_perolehan)', $exp[0]);
            }

            $data['barang_es'] = $this->barang->findAll();

			return view('pengadaan/barang', $data);
		} else {
            return redirect()->to('/pengadaan/barang');
		}
	}


    // ===========================================================================
	// PENGECEKAN
	// ===========================================================================	

	public function pengecekan($id = null)
	{
		$data["pengguna"] = $this->pengguna->find(session()->get('id_pengguna'));	
		
		if (!isset($id)) { 	
            $this->pengecekan->query("SET lc_time_names = 'id_ID';");
            $this->pengecekan->select('
                *,
                DATE_FORMAT(periode, "%W, %d %M %Y") AS _periode, 
            ');		
		    $this->pengecekan->orderBy('periode', 'DESC');
		    $data['pengecekan_es'] = $this->pengecekan->findAll();

            $data['kriteria_es'] = $this->kriteria->findAll();

			return view('pengadaan/pengecekan', $data);
		} else {
            return redirect()->to('/pengadaan/pengecekan');
		}
	}


    // ===========================================================================
	// PENGAJUAN
	// ===========================================================================	

	public function pengajuan($id = null)
	{
		$data["pengguna"] = $this->pengguna->find(session()->get('id_pengguna'));	
		
		if (!isset($id)) { 	
            $this->pengecekan->query("SET lc_time_names = 'id_ID';");
            $this->pengecekan->select('
                *,
                DATE_FORMAT(periode, "%W, %d %M %Y") AS _periode, 
            ');		
		    $this->pengecekan->orderBy('periode', 'DESC');
		    $data['pengecekan_es'] = $this->pengecekan->findAll();

			return view('pengadaan/pengajuan', $data);
		} else {
            return redirect()->to('/pengadaan/pengadaan');
		}
	}


    // ===========================================================================
	// PENGADAAN
	// ===========================================================================

	public function pengadaan($id = null)
	{
		$data["pengguna"] = $this->pengguna->find(session()->get('id_pengguna'));	
		
		if (!isset($id)) { 	
            $data['status_es'] = $this->status->findAll();

			return view('pengadaan/pengadaan', $data);
		} else {
            return redirect()->to('/pengadaan/pengadaan');
		}
	}

	// CRUD
	public function tambah_pengadaan()
	{
        $validation =  \Config\Services::validation();
        $validation->setRules([
            'nama_barang' => 'required',
            'merk' => 'required',
            'jumlah' => 'required',
            'harga_satuan' => 'required',
            'total_harga' => 'required',
        ]);
        $isDataValid = $validation->withRequest($this->request)->run();

        if ($isDataValid) {
            $this->pengadaan->insert([
                "nama_barang_pengadaan" => $this->request->getPost('nama_barang'),
                "merk_pengadaan" => $this->request->getPost('merk'),
                "jumlah_pengadaan" => $this->request->getPost('jumlah'),
                "harga_satuan" => $this->request->getPost('harga_satuan'),
                "total_harga" => $this->request->getPost('total_harga'),
            ]);
            
            echo 'sukses';
        } else {
            echo 'gagal';
        }
	}


    // ===========================================================================
	// PROFILE
	// ===========================================================================

    public function profile()
    {
        $this->pengguna->join('role', 'role.id_role = pengguna.role');
        $data["pengguna"] = $this->pengguna->find(session()->get('id_pengguna'));

        return view('pengadaan/profile', $data);
    }

    // CRUD
    public function edit_profile()
	{
        $validation =  \Config\Services::validation();
        $validation->setRules([
            'username' => 'required',
            // 'nama_pengguna' => 'required',
            'email' => 'required'
        ]);
        $isDataValid = $validation->withRequest($this->request)->run();
        
        if ($isDataValid) {
            $this->pengguna->update(session()->get('id_pengguna'), [
                "username" => $this->request->getPost('username'),
                // "nama_pengguna" => $this->request->getPost('nama_pengguna'),
                "email" => $this->request->getPost('email')
            ]);

            echo 'sukses';
        } else {
            echo 'gagal';
        }
	}

    public function edit_password_pengguna()
	{
        $validation =  \Config\Services::validation();
        $validation->setRules([
            'password' => 'required'
        ]);
        $isDataValid = $validation->withRequest($this->request)->run();
        
        if ($isDataValid) {
            $this->pengguna->update(session()->get('id_pengguna'), [
                "password" => md5($this->request->getPost('password')),
            ]);

            echo 'sukses';
        } else {
            echo 'gagal';
        }
	}

    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/login');
    }


    // ===========================================================================
	// DATATABLE
	// ===========================================================================

    public function get_pengecekan_detail()
	{
		$validation =  \Config\Services::validation();
        $validation->setRules([
            'id_pengecekan' => 'required',
            'kondisi' => 'required',
        ]);
        $isDataValid = $validation->withRequest($this->request)->run();
        
        if ($isDataValid) {
			$this->pengecekan_detail->join('barang', 'barang.id_barang = pengecekan_detail.barang');
            $this->pengecekan_detail->where('pengecekan', $this->request->getPost('id_pengecekan'));
            $this->pengecekan_detail->where('kondisi', $this->request->getPost('kondisi'));
            $hasil_es = $this->pengecekan_detail->findAll();

			$data = array();
            $i = 1;

            foreach ($hasil_es as $hasil) {
				$sub_array = array();
				$sub_array[] = $i++;
				$sub_array[] = $hasil['kode_barang'];
				$sub_array[] = $hasil['nup'];
                $sub_array[] = $hasil['nama_barang'];
                $sub_array[] = $hasil['merk'];
                $sub_array[] = $hasil['catatan'];
				$data[] = $sub_array;
			}

			$output = array(
				'draw'   => intval($this->request->getPost('draw')),
				'recordsTotal' => count($hasil_es),
				'recordsFiltered' => count($hasil_es),
				'data'   => $data
			);

			echo json_encode($output);
		} 
	}

    public function get_detail_pengadaan()
	{
        $this->pengadaan->query("SET lc_time_names = 'id_ID';");
        $this->pengadaan->select('
            *,
            DATE_FORMAT(modified, "%W, %d %M %Y - %H:%i:%s WIB") AS tanggal_konfirmasi, 
        ');	
        $this->pengadaan->join('status', 'status.id_status = pengadaan.status');
        $pengadaan = $this->pengadaan->find($this->request->getPost('id_pengadaan'));

        $output = array(
            'id_pengadaan'              => $pengadaan['id_pengadaan'],
            'nama_barang_pengadaan'     => $pengadaan['nama_barang_pengadaan'],
            'merk_pengadaan'            => $pengadaan['merk_pengadaan'],
            'jumlah_pengadaan'          => $pengadaan['jumlah_pengadaan'],
            'harga_satuan'              => "Rp " . number_format($pengadaan['harga_satuan'], 2, ',', '.'),
            'total_harga'               => "Rp " . number_format($pengadaan['total_harga'], 2, ',', '.'),
            'status'                    => $pengadaan['deskripsi_status'],
            'key'                       => $pengadaan['status'],
            'tanggal_konfirmasi'        => $pengadaan['tanggal_konfirmasi'],
        );

        echo json_encode($output);
	}

    public function get_jumlah_pengecekan()
	{
		$validation =  \Config\Services::validation();
        $validation->setRules([
            'id_pengecekan' => 'required',
        ]);
        $isDataValid = $validation->withRequest($this->request)->run();
        
        if ($isDataValid) {
            $this->pengecekan_detail->where('pengecekan', $this->request->getPost('id_pengecekan'));
            $this->pengecekan_detail->where('kondisi', 2);
            $jumlah_2 = count($this->pengecekan_detail->findAll());

            $this->pengecekan_detail->where('pengecekan', $this->request->getPost('id_pengecekan'));
            $this->pengecekan_detail->where('kondisi', 3);
            $jumlah_3 = count($this->pengecekan_detail->findAll());

			$output = array(
				'kondisi_2'     => $jumlah_2,
				'kondisi_3'     => $jumlah_3,
			);

			echo json_encode($output);
		} 
	}
}
