<?php

namespace App\Controllers;

use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\Controller;

class Administrator extends BaseController
{
    
    public function index()
    {
       
    } 

}
