<div class="box-body">
    <table id="<?php echo $id_tabel ?>" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Barang</th>
                <th>NUP</th>
                <th>Nama Barang</th>
                <th>Merk/Type</th>
                <th>Catatan</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Kode Barang</th>
                <th>NUP</th>
                <th>Nama Barang</th>
                <th>Merk/Type</th>
                <th>Catatan</th>
            </tr>
        </tfoot>
    </table>
</div>