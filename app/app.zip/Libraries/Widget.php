<?php namespace App\Libraries;

use App\Models\PengadaanModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Widget
{
    public function __construct() {
        $this->pengadaan = new PengadaanModel();
    }
    // public function date()
    // {
    //     date_default_timezone_set('Asia/Jakarta');
    //     return date('Y-m-d H:i:s');
    // }


    // public function recentPost(int $limit)
    // {
	// 	$data['limit'] = $limit;

    //     $blog = new BlogModel();
	// 	$blog->query("SET lc_time_names = 'id_ID';");
	// 	$blog->select('
    //         *,
    //         DATE_FORMAT(modified, "%W, %d %M %Y - %H:%i:%s") AS modified, 
    //         DATE_FORMAT(created, "%W, %d %M %Y - %H:%i:%s") AS created, 
    //     ');
    //     $blog->orderby("modified", "DESC");
    //     $data['recent_post'] = $blog->findAll();

    //     if (!$data['recent_post']) {
    //         throw PageNotFoundException::forPageNotFound();
    //     }

    //     return view('widget/recent_post', $data);
    // }

    public function pengadaan(array $params = [])
    {
		$data['id_tabel'] = $params['id_tabel'];
        $data['tambah'] = $params['tambah'];

        $this->pengadaan->join('status', 'status.id_status = pengadaan.status');
        $this->pengadaan->where('status', $params['status']);	
        $this->pengadaan->orderby("created", "DESC");	
        $data['pengadaan_es'] = $this->pengadaan->findAll();

        return view('widget/pengadaan', $data);
    }

    public function pengadaan_umum(array $params = [])
    {
		$data['id_tabel'] = $params['id_tabel'];

        $this->pengadaan->join('status', 'status.id_status = pengadaan.status');
        $this->pengadaan->where('status', $params['status']);	
        $this->pengadaan->orderby("created", "DESC");	
        $data['pengadaan_es'] = $this->pengadaan->findAll();

        return view('widget/pengadaan_umum', $data);
    }

    public function pengecekan(array $params = [])
    {
		$data['id_tabel'] = $params['id_tabel'];

        return view('widget/pengecekan', $data);
    }
}