<?= $this->extend('pengadaan/layout/pengadaan_layout') ?>

<?= $this->section('content') ?>

    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Data Pengecekan
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url('pengecekan') ?>"><i class="fa fa-dashboard"></i> Beranda</a></li>
                <li class="active">Data Pengecekan</li>
            </ol>
        </section>

        <section class="content">

            <div class="row">
                <div class="col-md-3">
                    <div class="box box-primary box-solid">
                        <div class="box-header with-border">
                            <h3 class="box-title">Cari Periode Pengecekan</h3>
                        </div>
                        <div class="box-body">

                            <form class="cari_pengecekan" id="cari_pengecekan">
                                <div class="form-group">
                                    <select id="id_pengecekan" name="id_pengecekan" class="form-control" required="" oninvalid="this.setCustomValidity('Periode Tidak Boleh Kosong')" oninput="setCustomValidity('')">
                                        <option value="">Pilih Periode</option>

                                        <?php foreach ($pengecekan_es as $pengecekan) : ?>
                                            <option value=<?php echo $pengecekan['id_pengecekan'] ?>> <?php echo $pengecekan['_periode'] ?></option>
                                        <?php endforeach; ?>   

                                    </select>
                                </div>

                                <button type="submit" class="btn btn-block btn-primary">Cari</button>
                            </form>
                            
                        </div>
                    </div>

                    <div class="box box-primary box-solid">
                        <div class="box-header with-border">
                            <h3 class="box-title">Detail Pengecekan</h3>
                        </div>
                        <div class="box-footer no-padding">
                            <ul class="nav nav-stacked">

                                <li class="active"> 
                                    <a href="#tab_2" data-toggle="tab">
                                        Masih Bisa Diperbaiki
                                        <span class="pull-right badge bg-blue" id="jumlah_2">0</span>
                                    </a>
                                </li>
                                <li> 
                                    <a href="#tab_3" data-toggle="tab">
                                        Rusak
                                        <span class="pull-right badge bg-blue" id="jumlah_3">0</span>
                                    </a>
                                </li>

                            </ul>
                            
                        </div>
                    </div>
                </div>

                <div class="col-md-9 col-xs-9">
                    <div class="nav-tabs-custom">
                        <div class="tab-content">

                            <div class="tab-pane active" id="tab_2">
                                <?= view_cell('\App\Libraries\Widget::pengecekan', ['id_tabel' => 'pengecekan_2']) ?>
                            </div>

                            <div class="tab-pane" id="tab_3">
                                <?= view_cell('\App\Libraries\Widget::pengecekan', ['id_tabel' => 'pengecekan_3']) ?>
                            </div>

                        </div>
                    </div>
                </div>
   
            </div>
        </section>
    </div>

<?= $this->endSection() ?>


<?= $this->section('javascript') ?>

    <script type="text/javascript" language="javascript" >
        $(document).ready(function(){
            $('#menu-master').addClass('active');

            $('#pengecekan_2').DataTable({
                "pageLength"  : 25, 
                dom: 'Blfrtip',
                buttons: [
                    {
                        extend: 'colvis',
                        text: 'Filter Data',
                        collectionLayout: 'fixed two-column',
                        postfixButtons: [ 'colvisRestore' ]
                    },
                ],
            });
            $('#pengecekan_3').DataTable({
                "pageLength"  : 25, 
                dom: 'Blfrtip',
                buttons: [
                    {
                        extend: 'colvis',
                        text: 'Filter Data',
                        collectionLayout: 'fixed two-column',
                        postfixButtons: [ 'colvisRestore' ]
                    },
                ],
            });
        })        
    </script>

    <script type="text/javascript">
        $('.cari_pengecekan').submit(function(e){
            e.preventDefault();     

            var id_pengecekan = $('#id_pengecekan').val();

            $.ajax({
                type: "post",
                url: "<?=base_url('pengadaan/get_jumlah_pengecekan')?>",
                dataType:'json',
                data: {
                    id_pengecekan:id_pengecekan,
                },
                success: function (data) {
                    $('#jumlah_2').html(data.kondisi_2);
                    $('#jumlah_3').html(data.kondisi_3);
                },
                error: function() {
                    
                }
            })  
            
            $('#pengecekan_2').DataTable().clear();
            $('#pengecekan_2').DataTable().destroy();
            $('#pengecekan_2').dataTable({
                "pageLength"  : 25, 
                responsive: true,
                dom: 'Blfrtip',
                buttons: [
                    {
                        extend: 'colvis',
                        text: 'Filter Data',
                        collectionLayout: 'fixed two-column',
                        postfixButtons: [ 'colvisRestore' ]
                    },
                ],
                'autoWidth'   : false,
                "ajax": {
                    url : "<?= base_url('pengadaan/get_pengecekan_detail')?>",
                    type : "POST",
                    data : {
                        id_pengecekan:id_pengecekan,
                        kondisi:2,
                    }
                }
            });  

            $('#pengecekan_3').DataTable().clear();
            $('#pengecekan_3').DataTable().destroy();
            $('#pengecekan_3').dataTable( {
                "pageLength"  : 25, 
                responsive: true,
                dom: 'Blfrtip',
                buttons: [
                    {
                        extend: 'colvis',
                        text: 'Filter Data',
                        collectionLayout: 'fixed two-column',
                        postfixButtons: [ 'colvisRestore' ]
                    },
                ],
                'autoWidth'   : false,
                "ajax": {
                    url : "<?= base_url('pengadaan/get_pengecekan_detail')?>",
                    type : "POST",
                    data : {
                        id_pengecekan:id_pengecekan,
                        kondisi:3,
                    }
                }
            });  

            return false; 
        });
    </script>

<?= $this->endSection() ?>