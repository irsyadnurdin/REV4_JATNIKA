<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0
    </div>
    <strong>
        Copyright &copy;2021 
        <a href="">JATNIKA</a>.
    </strong> All rights reserved.
</footer>